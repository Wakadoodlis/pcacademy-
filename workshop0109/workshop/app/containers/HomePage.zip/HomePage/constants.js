export const SET_DATA = 'SET_DATA';
export const SORT_DATA = 'SORT_DATA';
